Congrats, Board Icons installed successfully! To ensure Board Icons Language Strings are ready, you will be redirected so that your File Cache will be cleared.  After which, just edit any of your current parent or child boards to be able to set that Boards Icon.

Hope you enjoy this mod.