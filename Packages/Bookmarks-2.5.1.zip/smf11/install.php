<?php
db_query("
	CREATE TABLE IF NOT EXISTS {$db_prefix}bookmarks
	(
		`ID_MEMBER` mediumint(8) unsigned NOT NULL,
		`ID_TOPIC` mediumint(8) unsigned NOT NULL,
		UNIQUE KEY `ID_MEMBER` (`ID_MEMBER`,`ID_TOPIC`)
	)", __FILE__, __LINE__);
?>