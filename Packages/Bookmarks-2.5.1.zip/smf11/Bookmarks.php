<?php
if (!defined('SMF'))
	die('Hacking attempt...');

function Bookmarks()
{
	global $txt, $context, $scripturl, $settings, $modSettings, $user_info, $ID_MEMBER, $return, $smcFunc, $db_prefix;

	// Load the template
	loadTemplate('Bookmarks');
	
	// Kick users that don't have permission to make bookmarks.
	isAllowedTo('make_bookmarks');
	
	// Set the page title
	$context['page_title'] = $txt['bookmarks'];

	// Add it to the linktree
	$context['linktree'][] = array(
		'url' => $scripturl . '?action=bookmarks',
		'name' => $txt['bookmarks'],
		);

	// Determine whether we should run a subaction
	$context['sub_action'] = isset($_REQUEST['sa']) ? $_REQUEST['sa'] : '';
	
	switch ($context['sub_action'])
	{
		// Add a new bookmark
		case 'add':
		$return = !empty($_REQUEST['topic']) ? addBookmark(intval($_REQUEST['topic'])) : '';
		break;
		
		// Delete a bookmark
		case 'delete':
		$return = !empty($_POST['remove_bookmarks']) ? deleteBookmark($_POST['remove_bookmarks']) : '';
		break;
	}

	// Load this user's bookmarks
	$request = db_query("
		SELECT
			t.ID_TOPIC, t.numReplies, t.locked, t.numViews, t.ID_BOARD, b.name AS board_name,
			IFNULL(lt.ID_MSG, IFNULL(lmr.ID_MSG, -1)) + 1 AS new_from,
			t.ID_LAST_MSG, ml.posterTime AS last_poster_time,
			ml.ID_MSG_MODIFIED, ml.subject AS last_subject, ml.icon AS last_icon,
			ml.posterName AS last_member_name, ml.ID_MEMBER AS last_id_member,
			IFNULL(meml.realName, ml.posterName) AS last_display_name, t.ID_FIRST_MSG,
			mf.posterTime AS first_poster_time, mf.subject AS first_subject, mf.icon AS first_icon,
			mf.posterName AS first_member_name, mf.ID_MEMBER AS first_id_member,
			IFNULL(memf.realName, mf.posterName) AS first_display_name
		FROM {$db_prefix}bookmarks AS bm
			INNER JOIN {$db_prefix}topics AS t ON (bm.ID_TOPIC = t.ID_TOPIC)
			INNER JOIN {$db_prefix}boards AS b ON (t.ID_BOARD = b.ID_BOARD)
			INNER JOIN {$db_prefix}messages AS ml ON (ml.ID_MSG = t.ID_LAST_MSG)
			INNER JOIN {$db_prefix}messages AS mf ON (mf.ID_MSG = t.ID_FIRST_MSG)
			LEFT JOIN {$db_prefix}members AS meml ON (meml.ID_MEMBER = ml.ID_MEMBER)
			LEFT JOIN {$db_prefix}members AS memf ON (memf.ID_MEMBER = mf.ID_MEMBER)
			LEFT JOIN {$db_prefix}log_topics AS lt ON (lt.ID_TOPIC = t.ID_TOPIC AND lt.ID_MEMBER = $ID_MEMBER)
			LEFT JOIN {$db_prefix}log_mark_read AS lmr ON (lmr.ID_BOARD = t.ID_BOARD AND lmr.ID_MEMBER = $ID_MEMBER)
		WHERE
			bm.ID_MEMBER = {$ID_MEMBER}
			AND {$user_info['query_see_board']}
		ORDER BY t.id_last_msg DESC",
		__FILE__, __LINE__);

	$context['bookmarks'] = array();
	while ($row = mysql_fetch_assoc($request))
	{
		censorText($row['subject']);

		$context['bookmarks'][] = array(
			'id' => $row['ID_TOPIC'],
			'board' => array(
				'id' => $row['ID_BOARD'],
				'name' => $row['board_name'],
				'href' => $scripturl . '?board=' . $row['ID_BOARD'] . '.0',
				'link' => '<a href="' . $scripturl . '?board=' . $row['ID_BOARD'] . '.0">' . $row['board_name'] . '</a>'
			),
			'first_post' => array(
				'id' => $row['ID_FIRST_MSG'],
				'member' => array(
					'username' => $row['first_member_name'],
					'name' => $row['first_display_name'],
					'id' => $row['first_id_member'],
					'href' => !empty($row['first_id_member']) ? $scripturl . '?action=profile;u=' . $row['first_id_member'] : '',
					'link' => !empty($row['first_id_member']) ? '<a href="' . $scripturl . '?action=profile;u=' . $row['first_id_member'] . '" title="' . $txt[92] . ' ' . $row['first_display_name'] . '">' . $row['first_display_name'] . '</a>' : $row['first_display_name']
				),
				'time' => timeformat($row['first_poster_time']),
				'timestamp' => forum_time(true, $row['first_poster_time']),
				'subject' => $row['first_subject'],
				'icon' => $row['first_icon'],
				'icon_url' => $settings['images_url'] . '/post/' . $row['first_icon'] . '.gif',
				'href' => $scripturl . '?topic=' . $row['ID_TOPIC'] . '.0',
				'link' => '<a href="' . $scripturl . '?topic=' . $row['ID_TOPIC'] . '.0">' . $row['first_subject'] . '</a>'
			),
			'last_post' => array(
				'id' => $row['ID_LAST_MSG'],
				'member' => array(
					'username' => $row['last_member_name'],
					'name' => $row['last_display_name'],
					'id' => $row['last_id_member'],
					'href' => !empty($row['last_id_member']) ? $scripturl . '?action=profile;u=' . $row['last_id_member'] : '',
					'link' => !empty($row['last_id_member']) ? '<a href="' . $scripturl . '?action=profile;u=' . $row['last_id_member'] . '">' . $row['last_display_name'] . '</a>' : $row['last_display_name']
				),
				'time' => timeformat($row['last_poster_time']),
				'timestamp' => forum_time(true, $row['last_poster_time']),
				'subject' => $row['last_subject'],
				'icon' => $row['last_icon'],
				'icon_url' => $settings['images_url'] . '/post/' . $row['last_icon'] . '.gif',
				'href' => $scripturl . '?topic=' . $row['ID_TOPIC'] . ($user_info['is_guest'] ? ('.' . (!empty($options['view_newest_first']) ? 0 : ((int) (($row['numReplies']) / $context['pageindex_multiplier'])) * $context['pageindex_multiplier']) . '#msg' . $row['ID_LAST_MSG']) : (($row['numReplies'] == 0 ? '.0' : '.msg' . $row['ID_LAST_MSG']) . '#new')),
				'link' => '<a href="' . $scripturl . '?topic=' . $row['ID_TOPIC'] . ($user_info['is_guest'] ? ('.' . (!empty($options['view_newest_first']) ? 0 : ((int) (($row['numReplies']) / $context['pageindex_multiplier'])) * $context['pageindex_multiplier']) . '#msg' . $row['id_last_msg']) : (($row['numReplies'] == 0 ? '.0' : '.msg' . $row['ID_LAST_MSG']) . '#new')) . '" ' . ($row['numReplies'] == 0 ? '' : 'rel="nofollow"') . '>' . $row['last_subject'] . '</a>'
			),
			'icon' => $row['first_icon'],
			'icon_url' => $settings['theme_url'] . '/post/' . $row['first_icon'] . '.gif',
			'subject' => $row['first_subject'],
			'new' => $row['new_from'] <= $row['ID_MSG_MODIFIED'],
			'new_from' => $row['new_from'],
			'newtime' => $row['new_from'],
			'new_href' => $scripturl . '?topic=' . $row['ID_TOPIC'] . '.msg' . $row['new_from'] . '#new',
			'replies' => $row['numReplies'],
			'views' => $row['numViews'],
		);
	}
	mysql_free_result($request);
}

// Add a bookmark. Leave the second parameter empty to add for current user.
function addBookmark($id_topic, $id_member = null)
{
	global $txt, $context, $db_prefix;

	if ($id_member == null)
		$id_member = $context['user']['id'];

	// Is this already added as a bookmark?
	$result = db_query("
		SELECT *
		FROM {$db_prefix}bookmarks
		WHERE
			ID_MEMBER = $id_member AND
			ID_TOPIC = $id_topic
		LIMIT 1", __FILE__, __LINE__);
	
	// Save a little bit of memory
	$alreadyAdded = mysql_num_rows($result) != 0 ? true : false;
	mysql_free_result($result);

	// Only add it if it hasn't been added yet
	if ($alreadyAdded)
		return $txt['bookmark_add_exists'];
	else
	{
		$result = db_query("
			INSERT INTO {$db_prefix}bookmarks
			(ID_MEMBER, ID_TOPIC)
			VALUES
			($id_member, $id_topic)", __FILE__, __LINE__);
		
		// Success?
		if ($result)
			return $txt['bookmark_add_success'];
		
		// Failure
		else
			return $txt['bookmark_add_failed'];
	}
}

// Delete a bookmark. Leave the second parameter empty to remove for current user.
function deleteBookmark($topic_ids, $id_member = null)
{
	global $txt, $context, $db_prefix;

	if ($id_member == null)
		$id_member = $context['user']['id'];

	// Sanitize this a bit before querying the data
	foreach ($topic_ids as $index => $id)
		$topic_ids[$index] = (int) $id;

	$topics = implode(',', $topic_ids);

	$result = db_query("
		DELETE FROM {$db_prefix}bookmarks
		WHERE
			ID_TOPIC IN($topics) AND
			ID_MEMBER = $id_member", __FILE__, __LINE__);
	
	$deleted = mysql_affected_rows();

	// Success or failure?
	if ($result)
		return sprintf($txt['bookmark_delete_success'], $deleted);
	else
		return sprintf($txt['bookmark_delete_failure'], $deleted);
}
?>