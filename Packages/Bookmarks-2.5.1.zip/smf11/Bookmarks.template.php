<?php
function template_main()
{
	global $context, $settings, $scripturl, $txt, $return;

	// Show the linktree
	echo '
			<div>', theme_linktree(), '</div>';

	// Show $return when it's set
	if (!empty($return))
	{
		echo '
			<table align="center" cellpadding="15" cellspacing="0" class="tborder">
				<tr>
					<td class="windowbg">', $return, '</td>
				</tr>
			</table>
			<br />';
	}

	// Show the bookmark table title
	echo '
			<form action="', $scripturl, '?action=bookmarks;sa=delete" method="post">
				<table border="0" width="100%" cellspacing="1" cellpadding="5" class="bordercolor">
					<tr>
						<td class="catbg" colspan="8">', $txt['bookmark_list'], '</td>
					</tr>';

	// Show the bookmarks if there are any
	if (!empty($context['bookmarks']))
	{
		echo '
					<tr>
						<td class="titlebg"></td>
						<td class="titlebg">', $txt[70], '</td>
						<td class="titlebg" width="11%">', $txt[109], '</td>
						<td class="titlebg" width="4%">', $txt[110], '</td>
						<td class="titlebg" width="4%">', $txt[301], '</td>
						<td class="titlebg" width="22%">', $txt[111], '</td>
						<td class="titlebg" width="3%" align="center"><input type="checkbox" class="check" onclick="invertAll(this, this.form);" /></td>
					</tr>';

		foreach ($context['bookmarks'] as $topic)
		{
			// Show the topic's subject
			echo '
					<tr>
						<td class="windowbg2" width="4%" align="center">
							<img src="', $topic['first_post']['icon_url'], '" alt="" />
						</td>
						<td class="windowbg" valign="middle">
							', $topic['first_post']['link'];
				
			// Any new replies?
			if ($topic['new'])
				echo ' <a href="', $topic['new_href'], '"><img src="', $settings['images_url'], '/', $context['user']['language'], '/new.gif" alt="', $txt[302], '" /></a>';

			// Show the board the topic was posted in, as well as a link to the profile of the topic starter	
			echo '<br />
							<span class="smalltext"><i>', $txt['smf88'], ' ', $topic['board']['link'], '</i></span>
						</td>
						<td class="windowbg2" valign="middle">', $topic['first_post']['member']['link'], '</td>
						<td class="windowbg" valign="middle" align="center">', $topic['replies'], '</td>
						<td class="windowbg" valign="middle" align="center">', $topic['views'], '</td>
						<td class="windowbg2" valign="middle">
							<a href="', $topic['last_post']['href'], '"><img src="', $settings['images_url'], '/icons/last_post.gif" alt="', $txt[111], '" title="', $txt[111], '" style="float: right;" /></a>
							<span class="smalltext">
								', $topic['last_post']['time'], '<br />
								', $txt[525], ' ', $topic['last_post']['member']['link'], '
							</span>
						</td>
						<td class="windowbg2" valign="middle" align="center"><input type="checkbox" name="remove_bookmarks[]" value="', $topic['id'], '" class="check" /></td>
					</tr>';
		}

		echo '
					<tr>
						<td colspan="8" class="windowbg2" align="right">
							<input type="submit" name="send" value="', $txt['bookmark_delete'], '" />
						</td>
					</tr>';
	}
	// Show a message saying there aren't any bookmarks yet
	else
	{
		echo '
					<tr>
						<td colspan="3" class="windowbg2">', $txt['bookmark_list_empty'], '</td>
					</tr>';
	}

	echo '
				</table>
			</form>';
}
?>