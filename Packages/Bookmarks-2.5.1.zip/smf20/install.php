<?php
global $db_prefix, $smcFunc;

$smcFunc['db_create_table']($db_prefix . 'bookmarks',
	array(
		array(
			'name' => 'id_member',
			'type' => 'mediumint',
			'size' => 8,
		),
		array(
			'name' => 'id_topic',
			'type' => 'mediumint',
			'size' => 8,
		),		
	),
	array(
		array(
			'name' => 'bookmark',
			'type' => 'unique',
			'columns' => array('id_member', 'id_topic'),
		),
	),
	array(),
	'ignore');
?>