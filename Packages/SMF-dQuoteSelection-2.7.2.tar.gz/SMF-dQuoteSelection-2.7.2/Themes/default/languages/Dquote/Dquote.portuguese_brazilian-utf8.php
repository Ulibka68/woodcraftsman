<?php

$txt['dQuoteSelection_txt'] = 'Citar (texto selecionado)';
?>