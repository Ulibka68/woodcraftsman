<?php

$txt['dQuoteSelection_txt'] = 'Quote (selected)';
$txt['dQuoteSelection_notify_txt'] = 'quoted you in this message';
$txt['dQuoteSelection_mail_subject_txt'] = 'You were quoted';
