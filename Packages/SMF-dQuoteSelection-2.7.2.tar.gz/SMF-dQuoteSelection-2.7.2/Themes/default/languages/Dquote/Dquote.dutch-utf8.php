<?php

$txt['dQuoteSelection_txt'] = 'Citeer (selectie)';
?>