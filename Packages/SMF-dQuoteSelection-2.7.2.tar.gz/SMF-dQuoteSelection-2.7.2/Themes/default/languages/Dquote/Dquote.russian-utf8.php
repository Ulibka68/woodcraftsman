<?php

$txt['dQuoteSelection_txt'] = 'Цитировать (выделенное)';
$txt['dQuoteSelection_notify_txt'] = 'процитировал вас в сообщении';
$txt['dQuoteSelection_mail_subject_txt'] = 'Вас процитировали на форуме';
