<?php

$txt['dQuoteSelection_txt'] = 'Quota (selezione)';
?>