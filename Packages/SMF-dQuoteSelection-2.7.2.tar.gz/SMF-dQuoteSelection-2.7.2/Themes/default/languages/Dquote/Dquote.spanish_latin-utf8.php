<?php
$txt['dQuoteSelection_txt'] = 'Cita (seleccionada)'; 
?>
