<?php
$settingsTable = mysql_query("
	REPLACE INTO {$db_prefix}settings
		(variable, value)
	VALUES ('urlLength', 50)");
?>
