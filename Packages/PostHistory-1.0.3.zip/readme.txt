[hr]
[center][color=red][size=16pt][b]Post History 1.0.3[/b][/size][/color]
[/center]
[hr]

[url=http://madjoki.com/smf-mods/post-history/]Official Website[/url]
[url=http://custom.simplemachines.org/mods/index.php?mod=1841]Modification Site[/url]
[url=http://www.simplemachines.org/community/index.php?topic=312474.0]Support Topic[/url]

[color=blue][b][size=12pt]Introduction[/size][/b][/color]
Allows to store old versions of posts and viewing edit history of post.
Permission can be set either to own or all posts and it's set by board.

[color=blue][b][size=12pt]Changelog[/size][/b][/color]
[color=blue][b][size=10pt]1.0.3[/size][/b][/color]
[list]
	[li]SMF 2.0.1 support[/li]
[/list]
[color=blue][b][size=10pt]1.0.2[/size][/b][/color]
[list]
	[li]SMF 2.0.1 support[/li]
[/list]
[color=blue][b][size=10pt]1.0.1[/size][/b][/color]
[list]
	[li]SMF 2.0 support[/li]
[/list]
[color=blue][b][size=10pt]1.0[/size][/b][/color]
[list]
	[li]Use hooks when possible[/li]
	[li]SMF 2.0 RC 5 support[/li]
[/list]

[color=blue][b][size=12pt]SMF Versions supported[/size][/b][/color]
Versions SMF 2.0.x are supported.

[color=blue][b][size=12pt]Languages supported[/size][/b][/color]
Translations for English, Finnish and Turkish are included.

[color=blue][b][size=12pt]Installation[/size][/b][/color]
When doing manual install you have to upload post_history directory in SMF directory and run install.php file included in directory.